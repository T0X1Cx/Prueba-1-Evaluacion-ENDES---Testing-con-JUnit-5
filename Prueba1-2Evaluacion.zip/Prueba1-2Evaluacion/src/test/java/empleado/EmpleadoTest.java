package empleado;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class EmpleadoTest {
	
	Empleado e;
	Empleado a;
	@BeforeEach
	void setUp() throws Exception {
		e = new Empleado();
		a = new Empleado();
		
		
	}
	@ParameterizedTest(name = "Test Get Nombre")
	@CsvSource ({
			"Angel,	Angel",
			"Pepe,	Pepe",
			"Adri,	Adri"
			
	})
	void testGetNombre(String nombre, String result) {
		e = new Empleado(nombre, "Medina");
		assertEquals(result, e.getNombre());
		
	}
	
	@ParameterizedTest(name = "Test Get Apellido")
	@CsvSource ({
			"Medina, Medina",
			"Ferrari,	Ferrari",
			"Gonzalez,	Gonzalez"
	})
	void testGetApellido(String apellido, String result) {
		e = new Empleado("Angel", apellido);
		assertEquals(result, e.getApellido());
		
	}

	@ParameterizedTest(name = "Test Get Edad")
	@CsvSource ({
			"20, 20",
			"10,	10",
			"45,	45"
	})
	void testGetEdad(int edad, int result) {
		e = new Empleado("Pepe", "Perez", edad);
		assertEquals(result, e.getEdad());
		
	}
	
	@ParameterizedTest(name = "Test Get Salario")
	@CsvSource ({
			"1400, 1400",
			"1700,	1700",
			"4500,	4500"
	})
	void testGetSalario(double salario, double result) {
		e = new Empleado("Angel", "Ferrari", 20, salario);
		assertEquals(result, e.getSalario());
		
	}

	@ParameterizedTest(name = "Test Get Salario")
	@CsvSource ({
			"Angel, Medina, 20, 2000, 1500, false",
			"Pepe, Perez, 40, 3000, 1000, false",
			"Daniel, Rojas, 50, 4000, 2000, true"
	})
	void testPlus(String nombre, String apellidos, int edad ,double salario, double sueldoPlus, boolean result) {
		e = new Empleado(nombre, apellidos, edad, salario);
		assertEquals(result, e.plus(sueldoPlus));
		
	}

	@ParameterizedTest(name = "Test Equals")
	@CsvSource ({
			"Angel, Medina, true",
			"Angel, Medina, true",
			"Daniel, Rojas, true"
	})
	void testEqualsEmpleado(String nombre, String apellidos, boolean result) {
		e = new Empleado(nombre, apellidos);
		a = new Empleado(nombre, apellidos);
		
		assertEquals(result, e.equals(a));
		
		
	}

	@ParameterizedTest(name = "Test CompareTo")
	@CsvSource ({
			"Angel, Medina, 20, 0",
			"Pepe, Perez, 18, -1",
			"Daniel, Rojas, 50, 1"
	})
	void testCompareTo(String nombre, String apellidos, int edad, int result) {
		a = new Empleado("Raul", "Dominguez", 20);
		e = new Empleado(nombre, apellidos, edad);
		assertEquals(result, e.compareTo(a));
		
	}

	@ParameterizedTest(name = "Test toString")
	@CsvSource ({
			"Angel, Medina, 20, 2000",
			"Pepe, Perez, 40, 3000",
			"Daniel, Rojas, 50, 4000"
	})
	void testToString(String nombre, String apellidos, int edad, double salario) {
		e = new Empleado(nombre, apellidos, edad, salario);
		equals("El empleado se llama "+nombre+" "+apellidos+" con "+edad+" años " +
                "y un salario de "+salario);
		
	}



	@ParameterizedTest(name = "Test ConstructorStringString")
	@CsvSource ({
			"Angel, Medina, Angel, Medina",
			"Pepe, Perez, Pepe, Perez",
			"Daniel, Rojas, Daniel, Rojas"
	})
	void testEmpleadoStringString(String nombre, String apellidos, String result1, String result2) {
		e = new Empleado(nombre, apellidos);
		assertEquals(result1, e.getNombre());
		assertEquals(result2, e.getApellido());
	}

	@ParameterizedTest(name = "Test ConstructorStringStringInt")
	@CsvSource ({
			"Angel, Medina, 20, Angel, Medina, 20",
			"Pepe, Perez, 30, Pepe, Perez, 30",
			"Daniel, Rojas, 40, Daniel, Rojas, 40"
	})
	void testEmpleadoStringStringInt(String nombre, String apellidos, int edad, String result1, String result2, int result3) {
		e = new Empleado(nombre, apellidos, edad);
		assertEquals(result1, e.getNombre());
		assertEquals(result2, e.getApellido());
		assertEquals(result3, e.getEdad());
		
	}

	@ParameterizedTest(name = "Test ConstructorStringStringInt")
	@CsvSource ({
			"Angel, Medina, 20, 2000, Angel, Medina, 20, 2000",
			"Pepe, Perez, 30, 3000, Pepe, Perez, 30, 3000",
			"Daniel, Rojas, 40, 4000, Daniel, Rojas, 40, 4000"
	})
	void testEmpleadoStringStringIntDouble(String nombre, String apellidos, int edad, double salario, String result1, String result2, int result3, double result4) {
		e = new Empleado(nombre, apellidos, edad, salario);
		assertEquals(result1, e.getNombre());
		assertEquals(result2, e.getApellido());
		assertEquals(result3, e.getEdad());
		assertEquals(result4, e.getSalario());
		
	}

}
