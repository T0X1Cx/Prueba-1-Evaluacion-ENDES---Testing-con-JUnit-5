package cuentas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CuentaTest {
	
	Cuenta c;
	@BeforeEach
	void setUp() throws Exception {
		c = new Cuenta("2000", "Prueba");
	}

	@Test
	void testIngresarPositivo() throws IngresoNegativoException {
		c.ingresar("Ingreso Positivo", 100);
		assertEquals(100, c.getSaldo());
				
		
	}
	
	@Test
	void testIngresarNegativo() {
		IngresoNegativoException thrown = assertThrows(
				IngresoNegativoException.class, 
	            () -> c.ingresar("Ingreso dinero negativo", -100));
				assertEquals("No se puede ingresar una cantidad negativa", thrown.getMessage());
		
		
	}

	@Test
	void testRetirarIgualSaldo() throws IngresoNegativoException, SaldoInsuficienteException {
		testIngresarPositivo();
		c.retirar("Retirada igual", 100);
		assertEquals(0, c.getSaldo());
		
	}
	
	@Test
	void testRetirarImporteNegativo() throws IngresoNegativoException, SaldoInsuficienteException {
		testIngresarPositivo();
		IngresoNegativoException thrown = assertThrows(
				IngresoNegativoException.class, 
	            () -> c.retirar("Retiro Negativo", -100));
				assertEquals("No se puede retirar una cantidad negativa", thrown.getMessage());
		
		
	}
	
	@Test
	void testRetirarImporteSuperior() throws IngresoNegativoException, SaldoInsuficienteException {
		testIngresarPositivo();
		SaldoInsuficienteException thrown = assertThrows(
				SaldoInsuficienteException.class, 
	            () -> c.retirar("Retiro Negativo", 200));
				assertEquals("Saldo insuficiente", thrown.getMessage());
		
		
	}

	@Test
	void testGetSaldo() throws IngresoNegativoException {
		testIngresarPositivo();
		assertEquals(100, c.getSaldo());
		
	}

	@Test
	void testAddMovimiento() {
		Movimiento m = new Movimiento();
		m.setImporte(100);
		m.setConcepto("PruebaMovimiento");
		c.addMovimiento(m);
		
		assertEquals(c.mMovimientos.get(0), c.mMovimientos.get(0));
	}

}
