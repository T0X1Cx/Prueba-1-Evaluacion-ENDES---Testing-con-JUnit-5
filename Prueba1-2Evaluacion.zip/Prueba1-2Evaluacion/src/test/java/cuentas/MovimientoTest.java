package cuentas;

import static org.junit.jupiter.api.Assertions.*;

import org.hamcrest.Matcher;
import org.hamcrest.number.IsCloseTo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.hamcrest.MatcherAssert.assertThat; 
import static org.hamcrest.Matchers.*;

// TEST REALIZADOS USANDO HAMCREST 1.3

class MovimientoTest {

	Movimiento m;
	@BeforeEach
	void setUp() throws Exception {
		m = new Movimiento();
		m.setConcepto("ConceptoPrueba");
		m.setImporte(100);
		
	}
	
	@Test
	void testSetConcepto() {
		m.setConcepto("ConceptoPrueba1");
		
		assertThat("ConceptoPrueba1", is(m.getConcepto()));
	}

	@Test
	void testSetImporte() {
		m.setImporte(200);
		assertThat(m.getImporte(), is(closeTo(100.0, 100.0)));

	}

	
	@Test
	void testGetImporte() {
		assertThat(m.getImporte(), is(closeTo(50.0, 50.0)));
		
	}

	@Test
	void testGetConcepto() {
		assertThat("ConceptoPrueba", is(m.getConcepto()));
		
		
		
	}

	

}
